import os
import gnupg
import json
import random
import getpass
import hashlib
import jsonpickle
import ast
import signal

from collections import OrderedDict
from time import sleep
from gerarZeresima import gerarZeresima
from datetime import datetime
from enumEleitor import Eleitor
from gerarBu import gerarBoletim
from playsound import playsound


TIME_PATERN = "%H:%M:%S"
DATE_PATTERN = "%d/%m/%Y"
BARRA = ("\\" if os.name == "nt" else "/")



# Função para remover qualquer caractere acentuado de uma string. Retorna a string sem acentos.
def remove_especial(string):
    CARACTERES_ESPECIAIS = "ÁáÀàÉéÈèÍíìÌÓóÒòÚúÙùÂâÊêÎîÔôÛûÃãẼẽĨĩÕõŨũÑñÇç"
    CARACTERES_NORMAIS = "AaAaEeEeIiiIOoOoUuUuAaEeIiOoUuAaEeIiOoUuNnCc"
    nome = str(string)
    i=0
    retorno = list(nome)
    for char in retorno:
        j=0
        i+=1
        for char2 in CARACTERES_ESPECIAIS:
            j+=1
            if(char == char2):
                retorno[i-1]=CARACTERES_NORMAIS[j-1]
                j=0
                break
    
    return ''.join(retorno)


gpg = gnupg.GPG(gnupghome=f"{BARRA}home{BARRA}aluno{BARRA}.gnupg")

gpg.encoding = 'utf-8'


# Funções para retornar a data e o tempo corrente em um padrão definido.
def getDate(): return  datetime.now().strftime(DATE_PATTERN)
def getTime(): return  datetime.now().strftime(TIME_PATERN)


# Verifica se já existe um mesário já autenticado na seção (caso a luz caia, não é necessário realizar o login do mesário novamente).
def verificarMesarioCorrente():
    try:
        with open(f"mesarios{BARRA}mesarioCorrente.txt", "r") as MESARIO_CORRENTE:
            return json.loads(MESARIO_CORRENTE.read())
    except FileNotFoundError:
        return False


# Realiza a autenticação de um mesário através do seu nome e senha.
def autenticarMesario():
    while True:
        try:
            NOME_MESARIO = str(input("Digite o nome do mesário: ")).upper()
            try:
                with open(f"mesarios{BARRA}mesario{NOME_MESARIO}.txt", "r") as ARQUIVO_MESARIO_CORRENTE:
                    HASH_SENHA_MESARIO = ARQUIVO_MESARIO_CORRENTE.read().replace("\n","")
                    while True:
                        try:
                            SENHA_MESARIO = hashlib.sha256(getpass.getpass("\nSenha: ").encode('utf-8')).hexdigest()
                            if SENHA_MESARIO == HASH_SENHA_MESARIO:
                                with open(f"mesarios{BARRA}mesarioCorrente.txt", "w") as mesario_corrente:
                                    MESARIO_ATUAL = { "nome" : NOME_MESARIO, "senha" : HASH_SENHA_MESARIO}
                                    mesario_corrente.write(json.dumps(MESARIO_ATUAL))
                                return { "nome" : NOME_MESARIO, "senha" : HASH_SENHA_MESARIO}
                        except (EOFError, KeyboardInterrupt):
                            print("\033[31m\nImpossível realizar operação\n\033[0;0m")
            except FileNotFoundError:
                print("\033[31m\nNome inválido\n\033[0;0m")
        except (EOFError, KeyboardInterrupt):
            print("\033[31m\nImpossível realizar operação\n\033[0;0m")


#Limpa a tela do console de acordo com cada SO.
def limparTela():
    os.system('clear')


def parserArquivoJson(arquivoJson):
   return json.load(open(arquivoJson,"r",encoding="utf-8"),object_pairs_hook=OrderedDict)


def removerEspacosString(string):
    return str(string).strip()

'''
    Função que obtem o numero de eleitor e na qual pode ser realizado o fechamento da votação 
    (Apertando ctrl + c ou ctrl + d e digitando a senha do mesário corrente).
'''
def obterNumeroEleitor(SENHA_FIM_ELEICAO, boletim_urna, CARGOS, ARQUIVO_VOTOS,CHAVE_PRIV_URNA):
    while True:
        try:
            sleep(0.5)
            limparTela()
            NUMERO_ELEITOR = str(input("\nDigite seu ID de eleitor: "))
            if ((NUMERO_ELEITOR == '') or (not NUMERO_ELEITOR.isnumeric())):
                raise ValueError
            break
        except ValueError:
            print("\033[31m\nDigite apenas números\033[0;0m")
            continue
        except KeyboardInterrupt:
            try:
                finalizarEleicao(SENHA_FIM_ELEICAO, boletim_urna, CARGOS, ARQUIVO_VOTOS,CHAVE_PRIV_URNA)
            except (KeyboardInterrupt,EOFError):
                continue
        except EOFError:
            try:
                finalizarEleicao(SENHA_FIM_ELEICAO, boletim_urna, CARGOS, ARQUIVO_VOTOS,CHAVE_PRIV_URNA)
            except (KeyboardInterrupt,EOFError):
                continue

    return NUMERO_ELEITOR


def impedirParadaTerminal(signum, frame):
    print ('\033[31m\nImpossível Realizar essa operação\n\033[0;0m')


#Gera um json com boletim da urna corrente.
def gerarJson(boletim,URNA):
    with open(f'bu{BARRA}bu{URNA}.json', 'w') as convert_file:
        convert_file.write(json.dumps(boletim,indent=4))


def enterParaContinuar():
    while True:
        try:
            input("\n\nPressione ENTER para continuar")
            break
        except (KeyboardInterrupt,EOFError):
            continue


# Imprime a zerésima na tela, gera um json com os dados da zerésima e um .txt com os dados formatados.
def imprimirZerissima(boletim_urna,SECAO,URNA,NUMERO_ELEITORES_APTOS):
    boletim_urna["secao"] = str(SECAO)
    boletim_urna["urna"] = str(URNA)
    boletim_urna["data_hora"]["data_abertura"] = str(getDate())
    boletim_urna["data_hora"]["hora_abertura"] = str(getTime())
    boletim_urna["info_eleitores"]["eleitores_aptos"] = str(NUMERO_ELEITORES_APTOS)
    gerarJson(boletim_urna,URNA)
    gerarZeresima(boletim_urna,URNA)
    enterParaContinuar()
    return boletim_urna


'''
    Caso a senha inserida bata com a senha do mesario corrente, a votação é encerrada, o boletim de urna é 
    gerado e exibido na tela, é gerado um .txt com os dados do bu formatado e o arquivo contendo os votos 
    e assinado pela urna é gerado pronto para ser enviado para apuração.
'''
def finalizarEleicao(SENHA_FIM_ELEICAO, boletim_urna, CARGOS, ARQUIVO_VOTOS,CHAVE_PRIV_URNA):
    SENHA = hashlib.sha256(getpass.getpass("\nSenha: ").encode('utf-8')).hexdigest()
    if SENHA == SENHA_FIM_ELEICAO:
        print("\nFinalizando Eleição...\n")
        exibirBoletimUrna(boletim_urna,CARGOS,ARQUIVO_VOTOS)
        gerarArquivoApuracao(ARQUIVO_VOTOS,boletim_urna["urna"],CHAVE_PRIV_URNA)
        exit()


''' 
    Verifica se o número inserido pelo eleitor pertence a algum candidato, retornando True em caso afirmativo 
    e False, caso contrário.
'''
def validarVoto(PARTIDOS, CARGO, VOTO_ELEITOR):
    for partidos in PARTIDOS:
        for candidatos in partidos["candidatos"]:
            if candidatos["cargo"] == CARGO:
                if VOTO_ELEITOR == candidatos["codigo"]:
                    return True
    return False


''' 
    Espera pela confirmação do voto do eleitor. Caso seja digitado 'C' o voto é confirmado, já se for digitado 'E' 
    ele pode votar novamente em outro candidato.
'''
def confirmarVoto(CANDIDATOS_VALIDOS,cargo,codigo):
    while True:
        try:
            print(encontrarCandidato(CANDIDATOS_VALIDOS,cargo,codigo).upper())
            CONFIRMA_VOTO = str(input("\nPressione \033[32mC para confirmar o voto \033[0;0m\n\nPressione \033[31mE para corrigir o voto\033[0;0m\n\nOpção --> ")).lower()
            if CONFIRMA_VOTO == 'c':
                return True
            elif CONFIRMA_VOTO == 'e':
                return False
            else:
                limparTela()
        except:
            continue


# Pesquisa um candidato pelo seu código e retorna o seu cargo + nome + partido caso encontre.
def encontrarCandidato(CANDIDATOS_VALIDOS,cargo,codigo):
    if codigo == '0':
        return "\nBRANCO"
    else:
        for partido in CANDIDATOS_VALIDOS['partidos']:
            for candidato in partido["candidatos"]:
                if (candidato['cargo']==cargo and str(codigo) == str(candidato['codigo'])):
                    return '\n' + cargo + " : "+ candidato['nome'] + " - " + partido["nome_partido"]
    return "\nVOTO NULO"


'''
    Pesquisa na lista de eleitores pelo eleitor com o número fornecido e retorna seu nome. Retorna uma string vazia 
    caso não seja encontrado um eleitor que possua o número fornecido.
'''
def pesquisarNomeEleitor(NUMERO_ELEITOR, ELEITORES_VALIDOS):
    
    for eleitor in ELEITORES_VALIDOS:
        if eleitor["titulo"] == NUMERO_ELEITOR:
            return eleitor["nome"]
    return ""


# Verifica a assinatura da chave recursivamente até encontrar uma assinatura pertencente ao TSE.
def verificarAssinaturaTSE(FINGERPRINT_CHAVE,numeroChaves):
    FINGERPRINT_TSE = "FF0C12FAAE4231B3"
    if FINGERPRINT_TSE in FINGERPRINT_CHAVE and numeroChaves <= 3:
        return True
    elif numeroChaves < 3:
        try:
            assinatura_chave = gpg.list_keys(sigs=True,keys=FINGERPRINT_CHAVE)
            PROPRIETARIO_CHAVE = assinatura_chave.curkey.get("uids")[0]
            LISTA_ASSINATURA = assinatura_chave.curkey.get("sigs")
            for i in range(len(LISTA_ASSINATURA)):
                if PROPRIETARIO_CHAVE not in LISTA_ASSINATURA[i]:
                    return verificarAssinaturaTSE(LISTA_ASSINATURA[i][0],numeroChaves+1)
        except:
            return False
    else:
        return False


# Descriptografa os votos que estão no arquivo de votos e retorna uma lista de string contendo cada voto.

def obterListaVotos(PATH_ARQUIVO_VOTOS):
    lista_assinaturas = obterListaVotosAssinados(PATH_ARQUIVO_VOTOS)
    lista_votos_string = []
    
    for assinatura in lista_assinaturas:

        depickle_assinatura = jsonpickle.decode(assinatura)

        # Descriptografando a assinatura do mesário.
        decrypt_mesario_assinatura = gpg.decrypt(depickle_assinatura.data)
        if(verificarAssinaturaTSE(decrypt_mesario_assinatura.fingerprint,1)):
            depickle_voto = jsonpickle.decode(decrypt_mesario_assinatura.data)
            # Descriptografando a assinatura do eleitor e obtendo acesso ao dicionario com os votos.
            decrypt_voto = gpg.decrypt(depickle_voto.data,passphrase='eleitor')
            if(verificarAssinaturaTSE(decrypt_voto.fingerprint,1)):
                # Armazenando cada dicionario em uma lista.
                lista_votos_string.append(ast.literal_eval(decrypt_voto.data.decode("utf-8")))
            else:
                print("\033[31m\nCHAVE DE ELEITOR NÃO ASSINADA PELO TSE, FRAUDE DETECTADA!!!\n\nENCERRANDO ELEIÇÃO!!!\033[0;0m\n")
                exit()
        else:
            print("\033[31m\nCHAVE DO MESÁRIO NÃO ASSINADA PELO TSE, FRAUDE DETECTADA!!!\n\nENCERRANDO ELEIÇÃO!!!\033[0;0m\n")
            exit()

    return lista_votos_string


# Descriptografa os votos que estão no arquivo de votos e retorna uma lista de string formatadas em objetos sign.
def obterListaVotosAssinados(PATH_ARQUIVO_VOTOS):
    
    assinaturas = gpg.decrypt_file(PATH_ARQUIVO_VOTOS,always_trust=True)
    
    lista_assinaturas = assinaturas.data.decode("utf-8").split("\n")
    if lista_assinaturas[len(lista_assinaturas)-1] == '':
        lista_assinaturas.pop()

    for i in range(len(lista_assinaturas)):
        lista_assinaturas[i] += "\n"
    
    return lista_assinaturas


'''
    Obtém a lista de votos que já existem no arquivo de votos, decodifica o voto do eleitor atual, adiciona na lista de votos 
    existentes, embaralha tudo e escreve no arquivo de votos
'''
def encriptarVoto(voto_dicionario,CHAVE_PRIV_URNA,ELEITORES_VALIDOS,NUMERO_ELEITOR,MESARIO_SECAO):
    NOME_ELEITOR = remove_especial(pesquisarNomeEleitor(NUMERO_ELEITOR,ELEITORES_VALIDOS).replace(" ",""))
    NOME_MESARIO = MESARIO_SECAO["nome"]
    PATH_ARQUIVO_VOTOS = f"votos{BARRA}votos.txt"
    PATH_CHAVE_PRIV_ELEITOR = f"chaves{BARRA}eleitores{BARRA}priv-{NOME_ELEITOR}.pem"
    PATH_CHAVE_PRIV_MESARIO = f"chaves{BARRA}priv-{NOME_MESARIO}.pem"
    CHAVE_PRIV_ELEITOR = importarChave(PATH_CHAVE_PRIV_ELEITOR)
    CHAVE_PRIV_MESARIO = importarChave(PATH_CHAVE_PRIV_MESARIO)

    try:
        lista_votos = []
        with open(PATH_ARQUIVO_VOTOS,"r", encoding="utf-8") as arquivo_votos:
            lista_votos = obterListaVotosAssinados(PATH_ARQUIVO_VOTOS)
    except FileNotFoundError:
        with open(PATH_ARQUIVO_VOTOS,"a", encoding="utf-8") as arquivo_votos:
            gpg.encrypt_file(arquivo_votos,CHAVE_PRIV_URNA.fingerprints[0],always_trust=True,
                    armor=True,output=PATH_ARQUIVO_VOTOS)

    # Transformando o voto de dicionario para string e assinando com chave privada do proprio eleitor.
    VOTO = str(voto_dicionario)
    assinatura_eleitor = gpg.sign(VOTO, keyid=CHAVE_PRIV_ELEITOR.fingerprints[0], passphrase='eleitor')

    # Objeto SIGN gerado a partir de um dicionário, que foi transformado em string.
    ASSINATURA_ELEITOR_STRING = jsonpickle.encode(assinatura_eleitor)

    assinatura_mesario = gpg.sign(ASSINATURA_ELEITOR_STRING, keyid=CHAVE_PRIV_MESARIO.fingerprints[0])
    OBJETO_VOTO = jsonpickle.encode(assinatura_mesario)
    
    lista_votos.append(OBJETO_VOTO+"\n")
    random.shuffle(lista_votos)
    gpg.encrypt(''.join(lista_votos),CHAVE_PRIV_URNA.fingerprints[0],always_trust=True,
                armor=True,output=PATH_ARQUIVO_VOTOS)


def votar(CARGOS,CANDIDATOS_VALIDOS,voto_dicionario):
    for cargo in CARGOS:
        while(True):
            try:
                limparTela()
                print("\n\n")
                print("*"*50)
                print("\nPara votar em branco, digite 0\n")
                print("*"*50)
                voto_eleitor = str(input(f"\n\nDigite seu voto para {cargo}: "))
                if(voto_eleitor.isnumeric()):
                    if(confirmarVoto(CANDIDATOS_VALIDOS,cargo,voto_eleitor)):
                        voto_dicionario["candidatos"][cargo] = voto_eleitor
                        break
                    else:
                        continue
                else:
                    continue
            except (KeyboardInterrupt,EOFError):
                continue
    return voto_dicionario


# Verifica caso um eleitor já votou ou não. Retorna uma constante definida na enumeração Eleitor.
def verificarEleitorJaVotou(NUMERO_ELEITOR, CHAVE_PUB_URNA):
      
    PATH_ARQUIVO = f"votos{BARRA}eleitoresJaVotaram.txt"
    try:
        with open(PATH_ARQUIVO, "r") as eleitoresJaVotaram:
            dados_arquivo = str(gpg.decrypt_file(PATH_ARQUIVO,always_trust=True)).split("\n")
            dados_arquivo.pop()
            for eleitor in dados_arquivo:
                if eleitor == NUMERO_ELEITOR:
                    return Eleitor.JA_VOTOU.value
            return Eleitor.VALIDO.value                
    except FileNotFoundError:
        with open(PATH_ARQUIVO, "a",encoding="utf-8") as eleitoresJaVotaram:
            gpg.encrypt_file(eleitoresJaVotaram,CHAVE_PUB_URNA.fingerprints[0],always_trust=True,
                             armor=True,output=PATH_ARQUIVO)
        return Eleitor.VALIDO.value


# Registra que o eleitor corrente da seção votou em um arquivo.
def registrarEleitorVotou(NUMERO_ELEITOR, CHAVE_PUB_URNA):
    PATH_ARQUIVO = f"votos{BARRA}eleitoresJaVotaram.txt"
    dados_arquivo = str(gpg.decrypt_file(PATH_ARQUIVO))
    dados_arquivo = dados_arquivo + NUMERO_ELEITOR + "\n"
    gpg.encrypt(dados_arquivo,CHAVE_PUB_URNA.fingerprints[0],always_trust=True,
                armor=True,output=PATH_ARQUIVO)    


# Exibe o boletim de urna na tela e escreve em um arquivo .txt com todos os dados formatados.
def exibirBoletimUrna(boletim_urna,CARGOS,PATH_ARQUIVO_VOTOS):

    lista_votos = (obterListaVotos(PATH_ARQUIVO_VOTOS))

    for voto in lista_votos: 
        for nome_cargo in CARGOS: 
            if voto["candidatos"][nome_cargo] == "0":
                boletim_urna["candidatos"][str(nome_cargo.lower()).replace(" ","_")][0]["votos_brancos"] = str(int(boletim_urna["candidatos"][str(nome_cargo.lower()).replace(" ","_")][0]["votos_brancos"])+1) 
            else:
                voto_nulo = True
                for candidatos in boletim_urna["candidatos"][str(nome_cargo.lower()).replace(" ","_")]: 
                    if("votos_brancos" in candidatos):
                        continue
                    if candidatos["codigo"] == voto["candidatos"][nome_cargo]:
                        candidatos["votos"] = str(int(candidatos["votos"])+1)
                        boletim_urna["candidatos"][str(nome_cargo.lower()).replace(" ","_")][0]["votos_validos"] = str(int(boletim_urna["candidatos"][str(nome_cargo.lower()).replace(" ","_")][0]["votos_validos"])+1)
                        voto_nulo = False
                        break
                if voto_nulo:
                    boletim_urna["candidatos"][str(nome_cargo.lower()).replace(" ","_")][0]["votos_nulos"] = str(int(boletim_urna["candidatos"][str(nome_cargo.lower()).replace(" ","_")][0]["votos_nulos"])+1)
    boletim_urna["info_eleitores"]["faltas"] = str(int(boletim_urna["info_eleitores"]["eleitores_aptos"]) - len(lista_votos)) 
    boletim_urna["info_eleitores"]["comparecimentos"] = str(len(lista_votos))
    boletim_urna["data_hora"]["data_fechamento"] = str(getDate())
    boletim_urna["data_hora"]["hora_fechamento"] = str(getTime())
    gerarBoletim(boletim_urna) 
       

# Função que gera o arquivo de apuração e assina com a chave da urna.
def gerarArquivoApuracao(PATH_ARQUIVO_VOTOS,URNA,CHAVE_PRIV_URNA):
    PATH_ARQUIVO_APURACAO = f"apuracao{BARRA}votos{URNA}.txt"
    PATH_ARQUIVO_ASSINATURA = f"apuracao{BARRA}votos{URNA}signature.txt"
    LISTA_VOTOS = obterListaVotos(PATH_ARQUIVO_VOTOS)
    with open(PATH_ARQUIVO_APURACAO,"w",encoding="utf8") as arquivo_votos:
        for voto in LISTA_VOTOS:
            arquivo_votos.write(str(voto) + "\n")
        arquivo_votos.write(f"Comparecimentos: {len(LISTA_VOTOS)}, Faltas: {40-len(LISTA_VOTOS)}")
    gpg.sign_file(PATH_ARQUIVO_APURACAO,keyid=CHAVE_PRIV_URNA.fingerprints[0],output=PATH_ARQUIVO_APURACAO)
    gpg.sign_file(PATH_ARQUIVO_APURACAO,keyid=CHAVE_PRIV_URNA.fingerprints[0],output=PATH_ARQUIVO_ASSINATURA,detach=True,clearsign=False)
    

# Verifica se o numero de eleitor inserido é valido (pertence a seção e se pertence a algum eleitor).
def numeroEleitorValido(NUMERO_ELEITOR, ELEITORES_VALIDOS, SECAO):
    for eleitor in ELEITORES_VALIDOS:
        if eleitor["titulo"] == NUMERO_ELEITOR and eleitor["secao"] == int(SECAO):
            return Eleitor.VALIDO.value
    return Eleitor.NUMERO_ELEITOR_INVALIDO.value


'''
    Importa uma chave a partir do path passado e verifica se a mesma é assinada pelo TSE. Caso seja, retorna
    a chave, caso não seja uma chave assinada pelo TSE encerra a eleição na hora.
'''
def importarChave(PATH_CHAVE):
    chave = gpg.import_keys_file(PATH_CHAVE)
    if PATH_CHAVE == f"chaves{BARRA}pub-tse.pem":
        gpg.trust_keys(chave.fingerprints[0],"TRUST_ULTIMATE")
    if(verificarAssinaturaTSE(chave.fingerprints[0],1)):
        return chave
    else:
        print(f"\033[31m\nCHAVE COM FINGERPRINT {chave.fingerprints[0]} NÃO CONTEM ASSINATURA DO TSE!!!\n\nENCERRANDO ELEIÇÃO!!!\033[0;0m\n")
        exit()


def iniciarVotacao():
    NUMERO_ELEITORES_APTOS = 40
    SECAO = "0005"
    URNA = "0005"
    ARQUIVO_JSON_ELEITORES = f"eleitores{BARRA}eleitores.json"
    ARQUIVO_JSON_CANDIDATOS = f"candidatos{BARRA}candidatos.json"
    ARQUIVO_JSON_BU = f"bu{BARRA}bu.json"
    ARQUIVO_VOTOS = f"votos{BARRA}votos.txt"
    ARQUIVO_CHAVE_PUB_TSE = f"chaves{BARRA}pub-tse.pem"
    ARQUIVO_CHAVE_PUB_CARTORIO = f"chaves{BARRA}pub-cartorio.pem"
    ARQUIVO_CHAVE_PUB_URNA = f"chaves{BARRA}pub-urna{URNA}.pem"
    ARQUIVO_CHAVE_PRIV_URNA = f"chaves{BARRA}priv-urna{URNA}.pem"
    CARGOS = ("Presidente", "Governador", "Senador", "Deputado Federal", "Deputado Estadual")
    ELEITORES_VALIDOS = parserArquivoJson(ARQUIVO_JSON_ELEITORES)
    CANDIDATOS_VALIDOS = parserArquivoJson(ARQUIVO_JSON_CANDIDATOS)
    importarChave(ARQUIVO_CHAVE_PUB_TSE)
    importarChave(ARQUIVO_CHAVE_PUB_CARTORIO)
    importarChave(ARQUIVO_CHAVE_PUB_URNA)
    CHAVE_PRIV_URNA = importarChave(ARQUIVO_CHAVE_PRIV_URNA)
    boletim_urna = parserArquivoJson(ARQUIVO_JSON_BU)
    signal.signal(signal.SIGTSTP, impedirParadaTerminal)
    signal.signal(signal.SIGQUIT, impedirParadaTerminal)
    MESARIO_SECAO = verificarMesarioCorrente()
    if not MESARIO_SECAO:
        MESARIO_SECAO = autenticarMesario()
        boletim_urna = imprimirZerissima(boletim_urna,SECAO,URNA,NUMERO_ELEITORES_APTOS)
    else:
        boletim_urna = parserArquivoJson(f"bu{BARRA}bu{URNA}.json")
    limparTela()
    
    while(True):
        voto_eleitor = { "candidatos" : {
            "Presidente" : "",
            "Governador" : "",
            "Senador" : "",
            "Deputado Federal" : "",
            "Deputado Estadual" : ""
        }}
        NUMERO_ELEITOR = removerEspacosString(obterNumeroEleitor(MESARIO_SECAO["senha"],boletim_urna, CARGOS, ARQUIVO_VOTOS,CHAVE_PRIV_URNA))
        ELEITOR_VALIDO = numeroEleitorValido(NUMERO_ELEITOR, ELEITORES_VALIDOS, SECAO)
        if ELEITOR_VALIDO == Eleitor.NUMERO_ELEITOR_INVALIDO.value or ELEITOR_VALIDO == Eleitor.SECAO_INVALIDA.value:
            limparTela()
            print("\033[31m\nNúmero de eleitor inválido!!!!\033[0;0m\n")
            try:
                sleep(0.5)
                continue
            except(EOFError,KeyboardInterrupt):
                continue
            
        elif(verificarEleitorJaVotou(NUMERO_ELEITOR,CHAVE_PRIV_URNA) == Eleitor.JA_VOTOU.value):
            limparTela()
            print("\033[31m\nEleitor já votou!!!!\033[0;0m\n")
            try:
                sleep(0.5)
                continue
            except(EOFError,KeyboardInterrupt):
                continue
        else:
            voto_dicionario = votar(CARGOS,CANDIDATOS_VALIDOS,voto_eleitor)
            encriptarVoto(voto_dicionario,CHAVE_PRIV_URNA,ELEITORES_VALIDOS,NUMERO_ELEITOR,MESARIO_SECAO)
            registrarEleitorVotou(NUMERO_ELEITOR,CHAVE_PRIV_URNA)
            limparTela()
            try:
               playsound("som_urna.mp3")
            except:
                pass
            print("\nObrigado por votar!!!\n")
            enterParaContinuar()


def main():
    iniciarVotacao()
    
            
if __name__ == "__main__":
    main()
