from enum import Enum

class Eleitor(Enum):
    VALIDO = 0
    NUMERO_ELEITOR_INVALIDO = 1
    SECAO_INVALIDA = 2
    JA_VOTOU = 3