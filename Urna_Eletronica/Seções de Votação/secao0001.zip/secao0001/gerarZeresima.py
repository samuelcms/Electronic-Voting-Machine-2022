from datetime import datetime
import os

COLUNAS_RELATORIO = 38
DATE_PATTERN = "%d/%m/%Y"
BLANK_LINE = "\n\n"
NEW_LINE = "\n"

BARRA = ("\\" if os.name == "nt" else "/")

def getDate(): return  datetime.now().strftime(DATE_PATTERN)

def gerarLinhaFormatada(nomeCampo, campo):

    deslocamento = (COLUNAS_RELATORIO - (len(nomeCampo) - 1))
    return f"{nomeCampo}{campo.rjust(deslocamento)}"

#gerarLinhaFormatada

def gerarCabecalho():
    
    cabecalho = ("JUSTIÇA ELEITORAL").center(COLUNAS_RELATORIO) + BLANK_LINE
    cabecalho += ("Tribunal Regional Eleitoral [Lab. Redes]").center(COLUNAS_RELATORIO) + BLANK_LINE
    cabecalho += ("1º Turno").center(COLUNAS_RELATORIO) + NEW_LINE
    cabecalho += (f"{getDate()}").center(COLUNAS_RELATORIO) + BLANK_LINE
    cabecalho += ("Zerésima").center(COLUNAS_RELATORIO) + BLANK_LINE
        
    return cabecalho

# gerarCabecalho()

def getInfoEleicao(boletimJson):
    
    infoEleicao = gerarLinhaFormatada("Município:", "Barbacena") + NEW_LINE
    infoEleicao += gerarLinhaFormatada("Seção:", boletimJson["secao"]) + NEW_LINE
    infoEleicao += gerarLinhaFormatada("Urna:", boletimJson["urna"]) + BLANK_LINE

    infoEleicao += gerarLinhaFormatada("Eleitores Aptos:", boletimJson["info_eleitores"]["eleitores_aptos"]) + NEW_LINE + BLANK_LINE
   

    infoEleicao += gerarLinhaFormatada("Data:", boletimJson["data_hora"]["data_abertura"]) + NEW_LINE
    infoEleicao += gerarLinhaFormatada("Hora:", boletimJson["data_hora"]["hora_abertura"]) + BLANK_LINE

    infoEleicao += "".center(COLUNAS_RELATORIO + 1, '=') + NEW_LINE
    
    return infoEleicao

# getInfoEleicao()

def getResCargo(boletimJson, nomeCabecalho, cargoCandidato):

    resCandidato = NEW_LINE + nomeCabecalho.center(COLUNAS_RELATORIO + 1, '-') + BLANK_LINE
    
    resCandidato += gerarLinhaFormatada("Votos Válidos:", boletimJson["candidatos"]["presidente"][0]["votos_validos"]) + NEW_LINE
    resCandidato += gerarLinhaFormatada("Votos Brancos:", boletimJson["candidatos"]["presidente"][0]["votos_brancos"]) + NEW_LINE
    resCandidato += gerarLinhaFormatada("Votos Nulos:", boletimJson["candidatos"]["presidente"][0]["votos_nulos"]) + BLANK_LINE

    deslocamento = 1 + (len(boletimJson["candidatos"][cargoCandidato][1]["codigo"]) - 2)
    resCandidato += gerarLinhaFormatada(f"ID{deslocamento * ' '}Nome", "Votos") + BLANK_LINE
    index = 1
    while index < len(boletimJson["candidatos"][cargoCandidato]):
        candidato = boletimJson["candidatos"][cargoCandidato][index]
        resCandidato += gerarLinhaFormatada(f"{candidato['codigo']} {candidato['nome']}", candidato["votos"]) + NEW_LINE       
        index += 1
        
    return resCandidato

# getResPresidente()

def gerarZeresima(boletim,URNA):
    
    boletimJson = boletim
    
    relatorio = gerarCabecalho()
    relatorio += getInfoEleicao(boletimJson)    
    relatorio += getResCargo(boletimJson, "PRESIDENTE", "presidente") 
    relatorio += getResCargo(boletimJson, "GOVERNADOR", "governador")
    relatorio += getResCargo(boletimJson, "SENADOR", "senador")
    relatorio += getResCargo(boletimJson, "DEP. FEDERAL", "deputado_federal")
    relatorio += getResCargo(boletimJson, "DEP. ESTADUAL", "deputado_estadual")
    with open(f"bu{BARRA}zeresima{URNA}.txt", "w", encoding="utf8") as arquivoZeresima:
        arquivoZeresima.write(relatorio)
    print(relatorio)

# getInfoUrna

def main():
    gerarZeresima()
                
if __name__ == "__main__":
    main()